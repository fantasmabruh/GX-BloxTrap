# GX BloxTrap Mobile

Projeto Android nativo (Java) com visual Black Premium e detalhes roxos.

## Compatibilidade
- Android 11 (API 30) ou superior
- `minSdk 30`
- `targetSdk 35`

## Recursos desta versão
- Abre o Roblox oficial se estiver instalado.
- Salva localmente a preferência de perfil visual.
- Exibe recomendações gerais de otimização segura.
- Explica as limitações de FastFlags no Android.

## Limitações importantes
Este app é um companion/launcher. Ele não altera arquivos privados do Roblox, não injeta código, não modifica memória e não garante a aplicação de FastFlags. O Android restringe esse tipo de acesso para aplicativos comuns.

## Como gerar o APK
1. Instale o Android Studio em um computador.
2. Abra a pasta `GXBloxTrapMobile` no Android Studio.
3. Aguarde a sincronização do Gradle e instale o Android SDK 35 quando solicitado.
4. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de debug será gerado em `app/build/outputs/apk/debug/app-debug.apk`.

Este ambiente de criação não possui Android SDK/Gradle configurados, então o APK ainda precisa ser compilado no Android Studio.

## Compilar sem PC pelo GitHub Actions
1. No celular, entre em github.com e crie uma conta ou faça login.
2. Crie um repositório novo e envie todos os arquivos desta pasta (incluindo `.github/workflows/build-apk.yml`).
3. Abra a aba **Actions** do repositório.
4. Se solicitado, habilite workflows.
5. Selecione **Build GX BloxTrap APK** e toque em **Run workflow**.
6. Quando terminar, abra a execução concluída e baixe o artefato **GX-BloxTrap-APK**.
7. Extraia o ZIP do artefato e instale `app-debug.apk`.

O build é feito nos servidores do GitHub; não exige computador. O APK de debug não é assinado para distribuição pública.
