package com.gxstore.bloxtrap;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(9, 9, 11);
    private final int CARD = Color.rgb(24, 24, 27);
    private final int PURPLE = Color.rgb(167, 139, 250);
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("gx_settings", MODE_PRIVATE);
        render();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density); }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(20), dp(16), dp(20), dp(20));
        l.setBackgroundColor(BG);
        return l;
    }

    private void render() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = column();
        scroll.setBackgroundColor(BG);
        scroll.addView(root);

        TextView brand = text("GX STORE   /   MOBILE", 12, PURPLE, true);
        brand.setLetterSpacing(.12f);
        root.addView(brand);

        TextView title = text("GX BloxTrap", 30, Color.WHITE, true);
        LinearLayout.LayoutParams titleP = new LinearLayout.LayoutParams(-1, -2);
        titleP.topMargin = dp(12);
        root.addView(title, titleP);
        TextView sub = text("ROBLOX COMPANION • ANDROID 11+", 11, 0xFF9CA3AF, true);
        LinearLayout.LayoutParams subP = new LinearLayout.LayoutParams(-1, -2);
        subP.topMargin = dp(5);
        root.addView(sub, subP);

        addCard(root, "LAUNCHER", "Abra o Roblox instalado no seu aparelho.", "ABRIR ROBLOX", v -> openRoblox());
        addCard(root, "PERSONALIZADOR", "Escolha e salve um perfil visual do GX BloxTrap.", 
            prefs.getString("profile", "Black Premium"), v -> showProfiles());
        addCard(root, "OTIMIZADOR", "Veja ajustes seguros do Android para melhorar a experiência.", 
            "VER RECOMENDAÇÕES", v -> showOptimization());
        addCard(root, "FASTFLAGS", "Consulte informações e compatibilidade. O app não injeta nem altera arquivos internos do Roblox.", 
            "ENTENDER FASTFLAGS", v -> showFlags());

        TextView footer = text("GX STORE  •  BUILD WITHOUT LIMITS", 10, 0xFF71717A, true);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, -2);
        fp.topMargin = dp(24);
        root.addView(footer, fp);
        setContentView(scroll);
    }

    private void addCard(LinearLayout root, String heading, String description, String action, View.OnClickListener click) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(16), dp(16), dp(16));
        card.setBackgroundColor(CARD);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.topMargin = dp(14);
        root.addView(card, cp);

        TextView h = text(heading, 12, PURPLE, true);
        h.setLetterSpacing(.08f);
        card.addView(h);
        TextView d = text(description, 14, 0xFFE4E4E7, false);
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-1, -2);
        dp.topMargin = dp(8);
        card.addView(d, dp);

        Button b = new Button(this);
        b.setText(action);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF6D28D9));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(48));
        bp.topMargin = dp(12);
        card.addView(b, bp);
        b.setOnClickListener(click);
    }

    private void openRoblox() {
        Intent launch = getPackageManager().getLaunchIntentForPackage("com.roblox.client");
        if (launch != null) startActivity(launch);
        else new AlertDialog.Builder(this).setTitle("Roblox não encontrado")
            .setMessage("Instale o Roblox pela Google Play Store e tente novamente.")
            .setPositiveButton("OK", null).show();
    }

    private void showProfiles() {
        String[] profiles = {"Black Premium", "Dark Minimal", "Purple Accent"};
        new AlertDialog.Builder(this).setTitle("Perfil visual")
            .setSingleChoiceItems(profiles, java.util.Arrays.asList(profiles).indexOf(prefs.getString("profile", profiles[0])),
                (dialog, which) -> {
                    prefs.edit().putString("profile", profiles[which]).apply();
                    Toast.makeText(this, "Perfil salvo: " + profiles[which], Toast.LENGTH_SHORT).show();
                    dialog.dismiss(); render();
                }).setNegativeButton("Fechar", null).show();
    }

    private void showOptimization() {
        new AlertDialog.Builder(this).setTitle("Otimização segura")
            .setMessage("• Feche apps que não estiver usando.\\n• Mantenha o Roblox atualizado.\\n• Use uma conexão Wi-Fi estável.\\n• Evite jogar enquanto o aparelho estiver superaquecido.\\n\\nEste app não altera processos, memória ou arquivos do Roblox.")
            .setPositiveButton("Entendi", null).show();
    }

    private void showFlags() {
        new AlertDialog.Builder(this).setTitle("FastFlags no Android")
            .setMessage("FastFlags são configurações internas do cliente Roblox. No Android, um app externo comum não pode garantir que elas sejam aplicadas. Esta versão oferece apenas informações; não injeta código, não modifica o cliente e não promete flags funcionais.")
            .setPositiveButton("OK", null).show();
    }
}
